<h1> Bonjour <?php  echo $nom." ".$prenom ?> </h1>
<a href="http://localhost/codeigniter/index.php/exemple/acceuil3">Accéder a ce site</a>