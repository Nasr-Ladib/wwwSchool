<p>Ici les postes</p>
<a href="http://localhost/codeigniter/index.php/exemple/acceuil2/<?php echo $name.'/'.$prenom  ?>">Accéder à l'acceuil</a>