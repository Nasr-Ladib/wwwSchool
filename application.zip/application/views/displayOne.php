<!DOCTYPE html>
<?php foreach($css_files as $file): ?>
<link type="text/css" rel="stylesheet" href="<?php echo $file; ?>" />
<?php endforeach; ?>
<?php foreach($js_files as $file): ?>
    <script src="<?php echo $file; ?>"></script>
<?php endforeach; ?>
<!-- saved from url=(0040)http://brain-pro.com/mroogle/single.html -->
<html><head><meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
<title>Mroogle | Single </title>


<link rel="stylesheet" href="<?php echo base_url('assets/theme/bootstrap.min.css'); ?>">
<link rel="stylesheet" href="<?php echo base_url('assets/theme/bootstrap-select.css'); ?>" >
<link  href="<?php echo base_url('assets/theme/style.css'); ?>" rel="stylesheet" type="text/css" media="all">
<!-- for-mobile-apps -->
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta name="keywords" content="Resale Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, 
Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, Sony Ericsson, Motorola web design">
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //for-mobile-apps -->
<!--fonts-->

<!--//fonts-->	
<!-- js -->
<script type="text/javascript" src="<?php echo base_url('assets/theme/jquery.min.js.téléchargement'); ?>" ></script>
<!-- js -->
<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
<script src="<?php echo base_url('assets/theme/bootstrap.min.js.téléchargement'); ?>"></script>
<script  src="<?php echo base_url('assets/theme/bootstrap-select.js.téléchargement'); ?>"></script>
<script>
  $(document).ready(function () {
    var mySelect = $('#first-disabled2');

    $('#special').on('click', function () {
      mySelect.find('option:selected').prop('disabled', true);
      mySelect.selectpicker('refresh');
    });

    $('#special2').on('click', function () {
      mySelect.find('option:disabled').prop('disabled', false);
      mySelect.selectpicker('refresh');
    });

    $('#basic2').selectpicker({
      liveSearch: true,
      maxOptions: 1
    });
  });
</script>
<script type="text/javascript" src="<?php echo base_url('assets/theme/jquery.leanModal.min.js.téléchargement'); ?>"></script>
<link href="<?php echo base_url('assets/theme/jquery.uls.css'); ?>"  rel="stylesheet">
<link href="<?php echo base_url('assets/theme/jquery.uls.grid.css'); ?>" rel="stylesheet">
<link href="<?php echo base_url('assets/theme/jquery.uls.lcd.css'); ?>"  rel="stylesheet">
<!-- Source -->
<script src="<?php echo base_url('assets/theme/jquery.uls.data.js.téléchargement'); ?>"></script>
<script src="<?php echo base_url('assets/theme/jquery.uls.data.utils.js.téléchargement'); ?>"></script>
<script src="<?php echo base_url('assets/theme/jquery.uls.lcd.js.téléchargement'); ?>"></script>
<script src="<?php echo base_url('assets/theme/jquery.uls.languagefilter.js.téléchargement'); ?>"></script>
<script src="<?php echo base_url('assets/theme/jquery.uls.regionfilter.js.téléchargement'); ?>"></script>
<script src="<?php echo base_url('assets/theme/jquery.uls.core.js.téléchargement'); ?>"></script>
<script>
			$( document ).ready( function() {
				$( '.uls-trigger' ).uls( {
					onSelect : function( language ) {
						var languageName = $.uls.data.getAutonym( language );
						$( '.uls-trigger' ).text( languageName );
					},
					quickList: ['en', 'hi', 'he', 'ml', 'ta', 'fr'] //FIXME
				} );
			} );
		</script>
		<link rel="stylesheet" href="<?php echo base_url('assets/theme/flexslider.css'); ?>" media="screen">
</head>
<body>
<div class="header">
		<div class="container">
			<div class="logo">
				<a href="http://brain-pro.com/mroogle/index.html"><img src="<?php echo base_url('assets/theme/logo.png'); ?>"></a>
			</div>
			<div class="header-right">
			<a class="account" href="http://brain-pro.com/mroogle/login.html">My Account</a>
			  <a class="account" href="http://brain-pro.com/mroogle/single.html#" style="margin-left:5px; border-radius:100px;padding: 6px 9px;">Ar</a>
            <a class="account" href="http://brain-pro.com/mroogle/single.html#" style="margin-left:5px; border-radius:100px;padding: 6px 9px;">En</a>
			</div>
		</div>
		</div>
	
	<div class="banner text-center">
	  <div class="container">    
			<h1>Sell or Advertise   <span class="segment-heading">    anything online </span> with Resale</h1>
			<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry</p>
			<a href="http://brain-pro.com/mroogle/post-ad.html">Post Free Ad</a>
	  </div>
	</div>
	<!--single-page-->
	<div class="single-page main-grid-border">
		<div class="container">
			<ol class="breadcrumb" style="margin-bottom: 5px;">
				<li><a href="http://brain-pro.com/mroogle/index.html">Home</a></li>
				<li><a href="http://brain-pro.com/mroogle/all-classifieds.html">All Ads</a></li>
				<li class="active"><a href="http://brain-pro.com/mroogle/mobiles.html">Mobiles</a></li>
				<li class="active">Mobile Phone</li>
			</ol>
			<div class="product-desc">
                <div style="padding: 10px">
                <?php print_r($output); ?>
            </div>
        </div>
		</div>
	</div>
	<!--//single-page-->
	<!--footer section start-->		
		<footer>
			<div class="footer-top">
				<div class="container">
					<div class="foo-grids">
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Who We Are</h4>
							<p>Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle.</p>
                                <p>Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle Mroogle.</p>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Help</h4>
							<ul>
								<li><a href="http://brain-pro.com/mroogle/howitworks.html">How it Works</a></li>						
								<li><a href="http://brain-pro.com/mroogle/sitemap.html">Sitemap</a></li>
								<li><a href="http://brain-pro.com/mroogle/faq.html">Faq</a></li>
								<li><a href="http://brain-pro.com/mroogle/feedback.html">Feedback</a></li>
								<li><a href="http://brain-pro.com/mroogle/contact.html">Contact</a></li>
								
							</ul>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Information</h4>
							<ul>
																<li><a href="http://brain-pro.com/mroogle/terms.html">Terms of Use</a></li>
								<li><a href="http://brain-pro.com/mroogle/popular-search.html">Popular searches</a></li>	
								<li><a href="http://brain-pro.com/mroogle/privacy.html">Privacy Policy</a></li>	
							</ul>
						</div>
						<div class="col-md-3 footer-grid">
							<h4 class="footer-head">Contact Us</h4>
							<span class="hq">Our headquarters</span>
							<address>
								<ul class="location">
									<li><span class="glyphicon glyphicon-map-marker"></span></li>
									<li>KSA KSA KSA KSA KSA KSA KSA KSA KSA KSA KSA KSA KSA KSA KSA KSA</li>
									<div class="clearfix"></div>
								</ul>	
								<ul class="location">
									<li><span class="glyphicon glyphicon-earphone"></span></li>
									<li>+00 966 533228877</li>
									<div class="clearfix"></div>
								</ul>	
								<ul class="location">
									<li><span class="glyphicon glyphicon-envelope"></span></li>
									<li><a href="mailto:info@mroogle.com">mail@mroogle.com</a></li>
									<div class="clearfix"></div>
								</ul>						
							</address>
						</div>
						<div class="clearfix"></div>
					</div>						
				</div>	
			</div>	
			<div class="footer-bottom text-center">
			<div class="container">
				<div class="footer-logo">
					<a href="http://brain-pro.com/mroogle/index.html"><img src="./Mroogle _ Single_files/logo.png"></a>
				</div>
				<div class="footer-social-icons">
					<ul>
						<li><a class="facebook" href="http://brain-pro.com/mroogle/single.html#"><span>Facebook</span></a></li>
						<li><a class="twitter" href="http://brain-pro.com/mroogle/single.html#"><span>Twitter</span></a></li>
						<li><a class="flickr" href="http://brain-pro.com/mroogle/single.html#"><span>Flickr</span></a></li>
						<li><a class="googleplus" href="http://brain-pro.com/mroogle/single.html#"><span>Google+</span></a></li>
						<li><a class="dribbble" href="http://brain-pro.com/mroogle/single.html#"><span>Dribbble</span></a></li>
					</ul>
				</div>
				<div class="copyrights">
					<p> © 2018 Mroogle. All Rights Reserved</p>
				</div>
				<div class="clearfix"></div>
			</div>
		</div>
		</footer>
        <!--footer section end-->

</body></html>