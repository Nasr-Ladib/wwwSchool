<?php
/**
 * Created by PhpStorm.
 * User: Asus
 * Date: 17/08/2018
 * Time: 13:11
 */

class Admin extends CI_Controller{

    public function __construct()
    {
        parent::__construct();
        $this->load->database('');
        $this->load->helper('url');
    }


    public function indexAdmin(){
        $this->load->view('back-end/dashboard');
        $this->load->view('back-end/home');
        $this->load->view('back-end/footer');
    }
    public function listAdmin(){
        $this->load->view('back-end/dashboard');
        $this->load->view('back-end/list');
        $this->load->view('back-end/footer');
    }
    public function loginAdmin(){
        $this->load->view('back-end/login');

    }

    public function formAdmin(){
        $this->load->view('back-end/dashboard');
        $this->load->view('back-end/form');
        $this->load->view('back-end/footer');
    }

}