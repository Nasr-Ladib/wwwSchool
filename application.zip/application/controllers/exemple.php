<?php
/**
 * Created by PhpStorm.
 * User: Asus
 * Date: 16/07/2018
 * Time: 10:37
 */
class Exemple extends CI_Controller{

    public function acceuil($id1,$id2){
        echo "Bonjour Le monde ".$id1." ".$id2;

    }
    public function acceuil2($nom,$prenom){
            $this->load->helpers('url');
           $this->load->view('menu','',true);
            $this->load->view('exemple', array('nom'=> $nom, 'prenom'=>$prenom));
    }
    public function acceuil3(){
        $this->load->view('post');

    }
}
