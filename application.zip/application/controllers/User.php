<?php
/**
 * Created by PhpStorm.
 * User: Asus
 * Date: 12/08/2018
 * Time: 21:22
 */
class User extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();

        $this->load->database('');
        $this->load->helper('url');
        $this->load->library('grocery_CRUD');
    }

    public function login()
    {

        $this->load->view('header');
        $this->load->view('login.php');

    }
    public function register()
    {

        $this->load->view('header');
        $this->load->view('register.php');

    }
    public function owenPosts($id){
        $this->load->view('headerWithImage');
        $this->load->view('footer');

    }
}
?>