<?php
/**
 * Created by PhpStorm.
 * User: Asus
 * Date: 23/07/2018
 * Time: 12:05
 */
class Accueil extends CI_Controller{


    public function display(){

        $this->load->view('headerWithImage.php');
        $this->load->view('accueil.php');
        $this->load->view('footer.php');

    }


}
